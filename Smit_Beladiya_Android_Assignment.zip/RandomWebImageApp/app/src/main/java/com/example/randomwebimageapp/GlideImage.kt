
//Name: Smit Beladiya (smit1888)
//Date: 08/11/2020

package com.example.randomwebimageapp


// region imports
import android.app.Activity
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target

// endregion
/*
* Created by Student Name on October 23, 2020
*/
class GlideImage {

    // region list of image url

    private val listOfImageUrls = mutableListOf<String>(
            "https://loremflickr.com/800/600",
            "https://source.unsplash.com/collection/630950/800x600",
            "https://www.placecage.com/g/800/600",
            "https://www.placecage.com/c/800/600",
            "https://placeimg.com/800/600/any",
            "https://placebear.com/640/360",
            "https://picsum.photos/640/360",
            "https://p-hold.com/400/300",
            "https://keywordimg.com/420x320/random",
            "https://placekitten.com/420/320",
            "https://placebeard.it/420/320"

    )

    //endregion


    private var listCounter = 0

    var lastURL = ""
        private set

    // region loadGlideImage function

    fun loadGlideImage(
        imageView: ImageView,
        context: Activity,
        progressBar: ProgressBar,
        url:String = getRandomImageURL()
    ){
        progressBar.visibility = View.VISIBLE
        Glide.with(context)
            .load(url)
                .listener(object:RequestListener<Drawable>{
                    override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                        progressBar.visibility = View.GONE
                        context.toast("Glide Load Failed:$url")
                        return false
                    }

                    override fun onResourceReady(resource: Drawable?, model: Any?, target: Target<Drawable>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                        progressBar.visibility = View.GONE
                        context.toast("Glide Load success")
                        imageView.setImageDrawable(resource)
                        return false
                    }
                })
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .into(imageView)

        lastURL = url
    }
    //endregion

    // region getRandomImageURL function
    private fun getRandomImageURL():String{

        lastURL = listOfImageUrls[listCounter]
        listCounter++
        if(listCounter == listOfImageUrls.size){
            listOfImageUrls.shuffle()
            listCounter = 0
        }
        return lastURL
    }

    //endregion

    // region init function
    init {
        listOfImageUrls.shuffle()

    }

    //endregion

    // region toast
    // Extension method
    fun Context.toast(message:String){
        Toast.makeText(TheApp.context,message, Toast.LENGTH_SHORT).show()
    }
    //endregion
}