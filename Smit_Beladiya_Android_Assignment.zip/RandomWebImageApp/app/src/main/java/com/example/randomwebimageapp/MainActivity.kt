
//Name: Smit Beladiya (smit1888)
//Date: 08/11/2020



package com.example.randomwebimageapp

//region imports
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.randomwebimageapp.databinding.ActivityMainBinding
//endregion

class MainActivity : AppCompatActivity() {

    private val glideImage = GlideImage()

    //region onCreate function
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val internetConnected = InternetConnected(this)

        if(!internetConnected.checkNetworkConnectivity()){
            AlertDialog.Builder(this)
                .setTitle(R.string.message_title)
                .setMessage(R.string.message_text)
                .setNegativeButton(R.string.quit){_,_ -> finishAffinity()}
                .show()
        }else{
            binding.getImageButton.setOnClickListener(){
                glideImage.loadGlideImage(binding.imageView1,this,binding.progressBar)
            }
            binding.getImageButton.callOnClick()
        }
    }
    //endregion

    //region toast
    // Extension method
    fun Context.toast(message:String){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
    }
    //endregion

}